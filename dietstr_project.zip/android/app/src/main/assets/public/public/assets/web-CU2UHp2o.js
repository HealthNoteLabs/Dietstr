import{W as n}from"./index-DZ4At1RQ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
